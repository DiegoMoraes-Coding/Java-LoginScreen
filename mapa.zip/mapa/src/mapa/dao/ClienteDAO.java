
package mapa.dao;


import mapa.model.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {
    
    public void inserir(Cliente usuario){
        //Comandos do banco de dados 
        String sql =  "INSERT INTO usuario(nome, login, senha, email) VALUES (?,?,?,?)";
        
        PreparedStatement ps;
        
        try {
        ps = Conexao.getConexao().prepareStatement(sql);
        ps.setString(1, usuario.getNome());
        ps.setString(2, usuario.getLogin());
        ps.setString(3, usuario.getSenha());
        ps.setString(4, usuario.getEmail());
        
        ps.execute();
        
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

public Cliente buscarUsuarioid(String login, String senha) throws SQLException {
    String sql = "SELECT id, nome, senha, email FROM usuario WHERE login = ? AND senha = ?";
    
    PreparedStatement ps = null;
    ResultSet rs = null;
    
    try {
        ps = Conexao.getConexao().prepareStatement(sql);
        ps.setString(1, login);
        ps.setString(2, senha); 
        
        rs = ps.executeQuery();
        
        Cliente u = null;
        
        if (rs.next()) {
            u = new Cliente();
            u.setId(rs.getInt("id"));
            u.setNome(rs.getString("nome"));
            u.setSenha(rs.getString("senha"));
            u.setEmail(rs.getString("email"));
        }
        
        return u;
    } catch (SQLException e) {
        e.printStackTrace();
        throw e; 
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

        
    }
    
    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Cliente BuscarUsuarioid(String text, String text0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
